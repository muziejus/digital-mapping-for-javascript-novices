setTimeout(function(){$("#response").html(function(){
//
//
// IGNORE EVERYTHING ABOVE THIS LINE

return "This text is coming from JavaScript." ;

// IGNORE EVERYTHING BELOW THIS LINE
//
//
}).addClass("alert alert-success");}, 1000);
