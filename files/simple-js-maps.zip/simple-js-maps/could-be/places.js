let places = [
  { coords: [42.334, -83.037], name: "Hastings St.", mentions: 2 },
  { coords: [40.809, -73.944], name: "Lenox Avenue", mentions: 2 },
  { coords: [39.09, -94.561], name: "18th & Vine", mentions: 1 },
  { coords: [39.1, -84.524], name: "5th & Mound", mentions: 1 },
  { coords: [29.956, -90.073], name: "Rampart", mentions: 1 }
] ;
